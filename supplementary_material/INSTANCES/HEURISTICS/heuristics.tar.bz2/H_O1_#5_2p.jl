#= Copyright (C) 2024
Nuno David Lopes.
Created:  2024/10/22
Last changed - N. Lopes:2025/03/21 10:56:01
=#

using DrWatson
@quickactivate "SoftIdea"


#######################################
# Jobs ID
g = [1 2 3 4 5 6 7 8]
# Number of molds available per job
o = [1 1 2 3 1 1 1 1]
# Job Quantities
n = [12 37 89 89 59 38 39 20]

# Number of shelves
p = 2

# Objective function parameters
α = 1
β = 6
#β = 3

# Heuristics parameters
# Partition size
Pg = 2

# Number of iterations — role per heuristic:
# SSM-SA and SA → number of simulated annealing moves (temperature steps)
# GRASP → number of independent runs 
# GA   → number of generations
Nit = 100

# Initial temperature
T0 = 5
# Final temperature
Tf = 0.01
# Decrease (jump) iteration for temperature
Tj = 3

# Global Time Limit (seconds)
Gl = 1800

# Solver parameters
# Time limit (seconds)
Tl = 30

# Solver selection: "Gurobi" or "HiGHS"
solver_name = "Gurobi"


#######################################
# Order Dictionary: DO NOT EDIT
order_dict = @dict g n o p α β T0 Tf Tj Pg Nit Gl Tl solver_name
# Order ID
const FILEBASENAME = splitext(basename(@__FILE__()))[1]
order_dict[:Oid] = "$(FILEBASENAME)_p_$(p)_nit_$(Nit)_Pg_$(Pg)_Tl_$(Tl)_Ts_$(T0)_$(Tf)_$(Tj)_Gl_$(Gl)"
# Add file and gitcommit stamps
@tag!(order_dict)
